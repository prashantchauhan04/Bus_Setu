/* ═══════════════════════════════════════════════════
   routes.js — Haryana Roadways Route Management, Search & Stations
   ═══════════════════════════════════════════════════ */

const RoutesManager = (() => {
  let routes = [];
  let currentRouteId = '';

  // Fetch all routes from server API
  async function fetchRoutes() {
    try {
      const res = await fetch('/api/routes');
      if (!res.ok) throw new Error('Network error loading routes');
      routes = await res.json();
      return routes;
    } catch (err) {
      console.error('Failed to fetch routes:', err);
      return routes;
    }
  }

  // Populate the route selector dropdown
  function populateSelector(selectorEl) {
    const selected = selectorEl.value;
    selectorEl.innerHTML = '<option value="">🗺️ Haryana Roadways Routes</option>';

    routes.forEach(route => {
      const option = document.createElement('option');
      option.value = route.id;
      const countText = route.activeBuses > 0 ? ` (${route.activeBuses} live)` : '';
      option.textContent = `${route.busNumber}: ${route.from} → ${route.to}${countText}`;
      if (route.id === selected) option.selected = true;
      selectorEl.appendChild(option);
    });
  }

  // Search routes by keyword (matches origin, destination, busNumber, operator/depot, or any intermediate stop)
  function searchRoutes(keyword) {
    if (!keyword || !keyword.trim()) return [];
    const q = keyword.toLowerCase().trim();

    return routes.filter(route => {
      const matchBus = (route.busNumber || '').toLowerCase().includes(q);
      const matchFrom = (route.from || '').toLowerCase().includes(q);
      const matchTo = (route.to || '').toLowerCase().includes(q);
      const matchType = (route.busType || '').toLowerCase().includes(q);
      const matchOperator = (route.operator || '').toLowerCase().includes(q);
      const matchStops = Array.isArray(route.stops) && route.stops.some(stop => {
        const name = typeof stop === 'object' ? stop.name : stop;
        return (name || '').toLowerCase().includes(q);
      });

      return matchBus || matchFrom || matchTo || matchType || matchOperator || matchStops;
    });
  }

  // Populate the bus selection list in modal
  function populateSelectList(containerEl, onSelect) {
    containerEl.innerHTML = '';

    if (!routes || routes.length === 0) {
      containerEl.innerHTML = '<p class="text-muted" style="text-align:center; padding:20px;">No routes registered yet. Tap "＋" to add a Haryana Roadways route!</p>';
      return;
    }

    routes.forEach(route => {
      const card = document.createElement('div');
      card.className = 'route-card';
      const liveBadge = route.activeBuses > 0 
        ? `<span class="route-card-active">● ${route.activeBuses} Live</span>` 
        : '<span class="text-muted" style="font-size:0.75rem;">Offline</span>';

      const operatorLabel = route.operator ? `<span class="route-card-operator">${route.operator}</span>` : '';

      card.innerHTML = `
        <span class="route-card-icon">🚌</span>
        <div class="route-card-info">
          <h4>${route.busNumber} ${operatorLabel}</h4>
          <p>${route.from} ➔ ${route.to} • ${route.busType || 'Haryana Roadways'}</p>
        </div>
        ${liveBadge}
      `;

      card.addEventListener('click', () => {
        if (onSelect) onSelect(route);
      });

      containerEl.appendChild(card);
    });
  }

  // Get route by ID
  function getRoute(id) {
    return routes.find(r => r.id === id) || null;
  }

  // Get all routes
  function getAll() {
    return routes;
  }

  function setCurrentRoute(routeId) {
    currentRouteId = routeId;
  }

  function getCurrentRouteId() {
    return currentRouteId;
  }

  return {
    fetchRoutes,
    populateSelector,
    populateSelectList,
    searchRoutes,
    getRoute,
    getAll,
    setCurrentRoute,
    getCurrentRouteId
  };
})();
