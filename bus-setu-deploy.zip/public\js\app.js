/* ═══════════════════════════════════════════════════
   app.js — Core Live Bus Tracker Application
   ═══════════════════════════════════════════════════ */

(function () {
  'use strict';

  // ── DOM References ────────────────────────────────
  const termsModal = document.getElementById('terms-modal');
  const termsCheckbox = document.getElementById('terms-checkbox');
  const acceptTermsBtn = document.getElementById('accept-terms-btn');

  const routeSelector = document.getElementById('route-selector');
  const gpsStatusIndicator = document.getElementById('gps-status-indicator');

  const routeSearchInput = document.getElementById('route-search-input');
  const clearSearchBtn = document.getElementById('clear-search-btn');
  const searchResultsDropdown = document.getElementById('search-results-dropdown');

  const busInfoPanel = document.getElementById('bus-info-panel');
  const closeInfoBtn = document.getElementById('close-info-btn');
  const editBusBtn = document.getElementById('edit-bus-btn');

  const shareLocationBtn = document.getElementById('share-location-btn');
  const simulateBtn = document.getElementById('simulate-btn');
  const addBusBtn = document.getElementById('add-bus-btn');

  const sharingBanner = document.getElementById('sharing-banner');
  const sharingRouteName = document.getElementById('sharing-route-name');
  const sharingAccuracyText = document.getElementById('sharing-accuracy-text');
  const stopSharingBtn = document.getElementById('stop-sharing-btn');

  const addBusModal = document.getElementById('add-bus-modal');
  const closeBusModal = document.getElementById('close-bus-modal');
  const addBusForm = document.getElementById('add-bus-form');

  const editBusModal = document.getElementById('edit-bus-modal');
  const closeEditModal = document.getElementById('close-edit-modal');
  const editBusForm = document.getElementById('edit-bus-form');

  const selectBusModal = document.getElementById('select-bus-modal');
  const closeSelectModal = document.getElementById('close-select-modal');
  const selectBusList = document.getElementById('select-bus-list');

  const shareAppBtn = document.getElementById('share-app-btn');
  const shareModal = document.getElementById('share-modal');
  const closeShareModal = document.getElementById('close-share-modal');
  const qrCodeImg = document.getElementById('qr-code-img');
  const shareUrlInput = document.getElementById('share-url-input');
  const copyUrlBtn = document.getElementById('copy-url-btn');
  const whatsappShareBtn = document.getElementById('whatsapp-share-btn');

  // ── State ─────────────────────────────────────────
  let map = null;
  let socket = null;
  let busMarkers = {};        // { [busId]: L.marker }
  let userMarker = null;      // L.marker for current user
  let routePolyline = null;   // L.polyline for active route line
  let stationMarkers = [];    // Array of L.marker for station pins
  let currentlySelectedRoute = null;

  // ── Initialize App ────────────────────────────────
  function init() {
    registerServiceWorker();
    checkTermsAccepted();
    initMap();
    initSocket();
    loadRoutes();
    bindEvents();
  }

  // ── Register PWA Service Worker ───────────────────
  function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(err => {
        console.log('SW Registration notice:', err.message);
      });
    }
  }

  // ── Terms & Conditions ────────────────────────────
  function checkTermsAccepted() {
    if (localStorage.getItem('bus-setu-terms') === 'accepted') {
      termsModal.classList.add('hidden');
    }
  }

  function acceptTerms() {
    localStorage.setItem('bus-setu-terms', 'accepted');
    termsModal.classList.add('hidden');
    showToast('✅ Welcome to BusSetu (बस सेतु)! Live tracking ready');
  }

  // ── Map Setup (Leaflet + OpenStreetMap) ───────────
  function initMap() {
    // Default center covering northern corridor (Delhi - Karnal - Haryana)
    map = L.map('map', {
      zoomControl: false,
      attributionControl: true
    }).setView([29.15, 77.05], 9);

    L.control.zoom({ position: 'bottomleft' }).addTo(map);

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Try locating user via GPS/network
    if (LocationTracker.isSupported()) {
      LocationTracker.getCurrentPosition()
        .then(pos => {
          updateGpsStatus(`GPS: ±${pos.accuracy}m`, true);
        })
        .catch(() => {
          updateGpsStatus('Network Mode', true);
        });
    }
  }

  function updateGpsStatus(text, isOnline) {
    if (gpsStatusIndicator) {
      gpsStatusIndicator.innerHTML = `<span class="signal-dot" style="background:${isOnline ? '#34d399' : '#f87171'}"></span> ${text}`;
    }
  }

  // ── Socket.io Real-Time Engine ────────────────────
  function initSocket() {
    socket = io();

    socket.on('connect', () => {
      console.log('🔌 Connected to live tracking engine');
      updateGpsStatus('Live Connected', true);
    });

    // Receive active buses when joining route
    socket.on('current-buses', (buses) => {
      clearBusMarkers();
      if (Array.isArray(buses)) {
        buses.forEach(bus => {
          addOrUpdateBusMarker(bus);
        });
      }
    });

    // Receive live coordinate update
    socket.on('location-update', (data) => {
      addOrUpdateBusMarker(data);
    });

    // Bus went offline
    socket.on('bus-offline', (data) => {
      removeBusMarker(data.busId);
    });

    // Route updated or new bus added by another passenger
    socket.on('routes-updated', async (payload) => {
      await loadRoutes();
      if (currentlySelectedRoute && payload && payload.route && payload.route.id === currentlySelectedRoute.id) {
        currentlySelectedRoute = payload.route;
        BusInfo.renderBusInfo(currentlySelectedRoute, busInfoPanel);
        renderRouteOnMap(currentlySelectedRoute);
      }
    });

    socket.on('disconnect', () => {
      console.log('🔌 Disconnected');
      updateGpsStatus('Reconnecting...', false);
    });
  }

  // ── Custom Markers ────────────────────────────────
  function createBusIcon() {
    return L.divIcon({
      className: 'bus-marker-icon',
      html: '<div class="bus-marker pulse">🚌</div>',
      iconSize: [42, 42],
      iconAnchor: [21, 21]
    });
  }

  function createUserIcon() {
    return L.divIcon({
      className: 'bus-marker-icon',
      html: '<div class="bus-marker user-marker">📍</div>',
      iconSize: [42, 42],
      iconAnchor: [21, 21]
    });
  }

  function createStationIcon() {
    return L.divIcon({
      className: 'station-marker-icon',
      html: '<div class="station-pin"></div>',
      iconSize: [14, 14],
      iconAnchor: [7, 7]
    });
  }

  function addOrUpdateBusMarker(data) {
    const { busId, lat, lng, routeId, speed } = data;
    if (lat == null || lng == null) return;

    const route = RoutesManager.getRoute(routeId);
    const busLabel = route ? `${route.busNumber}` : 'Active Bus';
    const speedInfo = speed ? ` • ${speed} km/h` : '';

    if (busMarkers[busId]) {
      busMarkers[busId].setLatLng([lat, lng]);
      busMarkers[busId].setTooltipContent(`🚌 ${busLabel}${speedInfo}`);
    } else {
      const marker = L.marker([lat, lng], { icon: createBusIcon() }).addTo(map);

      marker.bindTooltip(`🚌 ${busLabel}${speedInfo}`, {
        permanent: false,
        direction: 'top',
        offset: [0, -22]
      });

      marker.on('click', () => {
        if (route) {
          currentlySelectedRoute = route;
          showBusInfo(route);
        }
      });

      busMarkers[busId] = marker;
    }
  }

  function removeBusMarker(busId) {
    if (busMarkers[busId]) {
      map.removeLayer(busMarkers[busId]);
      delete busMarkers[busId];
    }
  }

  function clearBusMarkers() {
    Object.keys(busMarkers).forEach(id => {
      map.removeLayer(busMarkers[id]);
    });
    busMarkers = {};
  }

  function updateUserMarker(lat, lng, accuracy) {
    if (userMarker) {
      userMarker.setLatLng([lat, lng]);
    } else {
      userMarker = L.marker([lat, lng], { icon: createUserIcon() }).addTo(map);
      userMarker.bindTooltip('📍 Your Live Location', { direction: 'top', offset: [0, -22] });
    }

    if (sharingAccuracyText && accuracy) {
      sharingAccuracyText.textContent = `GPS accuracy: ±${accuracy}m`;
    }
  }

  // ── Render Route Path & Stations on Map ───────────
  function renderRouteOnMap(route) {
    if (routePolyline) {
      map.removeLayer(routePolyline);
      routePolyline = null;
    }
    stationMarkers.forEach(m => map.removeLayer(m));
    stationMarkers = [];

    if (!route || !Array.isArray(route.stops)) return;

    const validCoords = [];
    route.stops.forEach((stop) => {
      if (typeof stop === 'object' && stop && stop.lat != null && stop.lng != null) {
        validCoords.push([stop.lat, stop.lng]);

        const stationMarker = L.marker([stop.lat, stop.lng], { icon: createStationIcon() }).addTo(map);
        stationMarker.bindTooltip(`🚏 ${stop.name}`, { direction: 'top', offset: [0, -10] });
        stationMarkers.push(stationMarker);
      }
    });

    if (validCoords.length > 1) {
      routePolyline = L.polyline(validCoords, {
        color: '#1a73e8',
        weight: 5,
        opacity: 0.85,
        dashArray: '8, 8'
      }).addTo(map);

      map.fitBounds(routePolyline.getBounds(), { padding: [50, 50] });
    }
  }

  // ── Route Loading & Switching ─────────────────────
  async function loadRoutes() {
    await RoutesManager.fetchRoutes();
    RoutesManager.populateSelector(routeSelector);
  }

  function switchRoute(routeId) {
    RoutesManager.setCurrentRoute(routeId);

    if (routeId) {
      const route = RoutesManager.getRoute(routeId);
      currentlySelectedRoute = route;
      if (route) {
        showBusInfo(route);
        renderRouteOnMap(route);
        routeSearchInput.value = `${route.from} ➔ ${route.to}`;
        clearSearchBtn.classList.remove('hidden');
      }
      socket.emit('join-route', routeId);
    } else {
      currentlySelectedRoute = null;
      hideBusInfo();
      if (routePolyline) {
        map.removeLayer(routePolyline);
        routePolyline = null;
      }
      stationMarkers.forEach(m => map.removeLayer(m));
      stationMarkers = [];
      routeSearchInput.value = '';
      clearSearchBtn.classList.add('hidden');
      socket.emit('join-route', '');
    }
  }

  // ── Live Route Search & Finder Logic ──────────────
  function handleRouteSearch(e) {
    const query = e.target.value.trim();

    if (!query) {
      clearSearchBtn.classList.add('hidden');
      searchResultsDropdown.classList.add('hidden');
      return;
    }

    clearSearchBtn.classList.remove('hidden');
    const matched = RoutesManager.searchRoutes(query);

    if (matched.length === 0) {
      searchResultsDropdown.innerHTML = `<div class="search-result-item" style="color:var(--gray); text-align:center; padding:12px;">No matching routes found for "${query}". Tap ＋ to add it!</div>`;
      searchResultsDropdown.classList.remove('hidden');
      return;
    }

    let html = '';
    matched.forEach(route => {
      const stopNames = (route.stops || []).map(s => typeof s === 'object' ? s.name : s).join(' ➔ ');
      const liveBadge = route.activeBuses > 0 ? `<span class="badge badge-green">● ${route.activeBuses} Live</span>` : '';

      html += `
        <div class="search-result-item" data-route-id="${route.id}">
          <div class="search-result-header">
            <span>🚌 ${route.busNumber}: ${route.from} ➔ ${route.to}</span>
            ${liveBadge}
          </div>
          <div class="search-result-stops">Via: ${stopNames}</div>
        </div>
      `;
    });

    searchResultsDropdown.innerHTML = html;
    searchResultsDropdown.classList.remove('hidden');

    // Attach click handlers to search results
    searchResultsDropdown.querySelectorAll('.search-result-item').forEach(item => {
      item.addEventListener('click', () => {
        const routeId = item.getAttribute('data-route-id');
        if (routeId) {
          routeSelector.value = routeId;
          switchRoute(routeId);
          searchResultsDropdown.classList.add('hidden');
        }
      });
    });
  }

  // ── Bus Info Panel ────────────────────────────────
  function showBusInfo(route) {
    BusInfo.renderBusInfo(route, busInfoPanel);
    busInfoPanel.classList.remove('hidden');
  }

  function hideBusInfo() {
    busInfoPanel.classList.add('hidden');
  }

  // ── Location Sharing (Live Passenger) ─────────────
  function startSharing(route) {
    const busId = `bus-${route.busNumber}-${socket.id.slice(0, 5)}`;

    LocationTracker.getCurrentPosition()
      .then(pos => {
        map.setView([pos.lat, pos.lng], 15);
        updateUserMarker(pos.lat, pos.lng, pos.accuracy);

        const started = LocationTracker.startTracking(busId, route.id, socket, (newPos) => {
          updateUserMarker(newPos.lat, newPos.lng, newPos.accuracy);
        });

        if (started) {
          shareLocationBtn.querySelector('.fab-text').textContent = 'Stop Sharing';
          shareLocationBtn.classList.add('active');

          sharingRouteName.textContent = `${route.busNumber}`;
          sharingAccuracyText.textContent = `GPS accuracy: ±${pos.accuracy}m`;
          sharingBanner.classList.remove('hidden');

          selectBusModal.classList.add('hidden');
          showToast(`📡 Live sharing started for ${route.busNumber}`);
        }
      })
      .catch(err => {
        showToast('⚠️ Could not access GPS. Please enable location permissions.');
        console.error(err);
      });
  }

  function stopSharing() {
    LocationTracker.stopTracking(socket);

    if (userMarker) {
      map.removeLayer(userMarker);
      userMarker = null;
    }

    shareLocationBtn.querySelector('.fab-text').textContent = 'Share Location';
    shareLocationBtn.classList.remove('active');
    simulateBtn.classList.remove('active');
    sharingBanner.classList.add('hidden');

    showToast('🔴 Stopped sharing location');
  }

  // ── Simulation / Demo Mode ────────────────────────
  function toggleSimulation() {
    const state = LocationTracker.getSharingState();

    if (state.isSimulating) {
      stopSharing();
    } else {
      const routes = RoutesManager.getAll();
      if (!routes || routes.length === 0) {
        showToast('❌ No routes available to simulate');
        return;
      }

      const routeToSimulate = currentlySelectedRoute || routes[0];
      routeSelector.value = routeToSimulate.id;
      switchRoute(routeToSimulate.id);

      LocationTracker.startSimulation(routeToSimulate, socket, (pos) => {
        updateUserMarker(pos.lat, pos.lng, pos.accuracy);
      });

      simulateBtn.classList.add('active');
      shareLocationBtn.querySelector('.fab-text').textContent = 'Stop Demo';
      shareLocationBtn.classList.add('active');

      sharingRouteName.textContent = `Demo: ${routeToSimulate.busNumber}`;
      sharingAccuracyText.textContent = `Simulated 38 km/h live feed`;
      sharingBanner.classList.remove('hidden');

      showToast(`⚡ Demo started! Simulating ${routeToSimulate.busNumber}`);
    }
  }

  // ── Event Handlers & Bindings ─────────────────────
  function bindEvents() {
    termsCheckbox.addEventListener('change', () => {
      acceptTermsBtn.disabled = !termsCheckbox.checked;
    });

    acceptTermsBtn.addEventListener('click', acceptTerms);

    // Route selector change
    routeSelector.addEventListener('change', (e) => {
      switchRoute(e.target.value);
    });

    // Search input listener
    routeSearchInput.addEventListener('input', handleRouteSearch);
    routeSearchInput.addEventListener('focus', handleRouteSearch);

    // Clear search button
    clearSearchBtn.addEventListener('click', () => {
      routeSearchInput.value = '';
      clearSearchBtn.classList.add('hidden');
      searchResultsDropdown.classList.add('hidden');
      routeSelector.value = '';
      switchRoute('');
    });

    // Click outside search results to dismiss dropdown
    document.addEventListener('click', (e) => {
      if (!e.target.closest('#search-container')) {
        searchResultsDropdown.classList.add('hidden');
      }
    });

    // Share Location Button
    shareLocationBtn.addEventListener('click', () => {
      const state = LocationTracker.getSharingState();

      if (state.isSharing) {
        stopSharing();
      } else {
        RoutesManager.populateSelectList(selectBusList, (route) => {
          startSharing(route);
        });
        selectBusModal.classList.remove('hidden');
      }
    });

    // Simulation Button
    simulateBtn.addEventListener('click', toggleSimulation);

    // Stop Sharing from banner
    stopSharingBtn.addEventListener('click', stopSharing);

    // Close Info panel
    closeInfoBtn.addEventListener('click', hideBusInfo);

    // Edit Bus Details Button in panel
    editBusBtn.addEventListener('click', () => {
      if (!currentlySelectedRoute) return;
      BusInfo.populateEditForm(editBusForm, currentlySelectedRoute);
      editBusModal.classList.remove('hidden');
    });

    // Add Bus Modal open/close
    addBusBtn.addEventListener('click', () => {
      addBusModal.classList.remove('hidden');
    });

    closeBusModal.addEventListener('click', () => {
      addBusModal.classList.add('hidden');
    });

    closeEditModal.addEventListener('click', () => {
      editBusModal.classList.add('hidden');
    });

    closeSelectModal.addEventListener('click', () => {
      selectBusModal.classList.add('hidden');
    });

    // Add Bus Form Submit
    addBusForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const data = BusInfo.parseAddForm(addBusForm);

      if (!data.busNumber || !data.from || !data.to) {
        showToast('❌ Please fill in bus number, start station, and destination');
        return;
      }

      try {
        const newRoute = await BusInfo.addBus(data);
        addBusForm.reset();
        addBusModal.classList.add('hidden');
        showToast(`✅ Bus ${newRoute.busNumber} added successfully!`);
        await loadRoutes();
        routeSelector.value = newRoute.id;
        switchRoute(newRoute.id);
      } catch (err) {
        showToast('❌ ' + err.message);
      }
    });

    // Edit Bus Form Submit
    editBusForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const { routeId, data } = BusInfo.parseEditForm(editBusForm);

      try {
        const updated = await BusInfo.updateBus(routeId, data);
        editBusModal.classList.add('hidden');
        showToast(`✅ Bus ${updated.busNumber} details updated!`);
        currentlySelectedRoute = updated;
        BusInfo.renderBusInfo(updated, busInfoPanel);
        renderRouteOnMap(updated);
        await loadRoutes();
      } catch (err) {
        showToast('❌ ' + err.message);
      }
    });

    // Share & QR Modal
    if (shareAppBtn) {
      shareAppBtn.addEventListener('click', () => {
        const currentUrl = window.location.origin;
        shareUrlInput.value = currentUrl;
        const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(currentUrl)}`;
        qrCodeImg.src = qrUrl;
        shareModal.classList.remove('hidden');
      });
    }

    if (closeShareModal) {
      closeShareModal.addEventListener('click', () => {
        shareModal.classList.add('hidden');
      });
    }

    if (copyUrlBtn) {
      copyUrlBtn.addEventListener('click', () => {
        shareUrlInput.select();
        navigator.clipboard.writeText(shareUrlInput.value)
          .then(() => showToast('📋 Link copied to clipboard!'))
          .catch(() => showToast('📋 Copied!'));
      });
    }

    if (whatsappShareBtn) {
      whatsappShareBtn.addEventListener('click', () => {
        const url = encodeURIComponent(window.location.origin);
        const text = encodeURIComponent('🚌 Bus Setu (बस सेतु) — Track live Haryana Bus Service, bus stands & routes in real-time! Open here: ');
        window.open(`https://api.whatsapp.com/send?text=${text}${url}`, '_blank');
      });
    }

    // Backdrop clicks to close modals
    [addBusModal, editBusModal, selectBusModal, shareModal].forEach(modal => {
      if (!modal) return;
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.add('hidden');
        }
      });
    });
  }

  document.addEventListener('DOMContentLoaded', init);

})();

// ── Global Toast Helper ───────────────────────────
function showToast(message) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    if (toast.parentNode) toast.remove();
  }, 3200);
}
