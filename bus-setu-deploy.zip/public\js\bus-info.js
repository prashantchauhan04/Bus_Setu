/* ═══════════════════════════════════════════════════
   bus-info.js — Add & Edit Crowdsourced Bus Info
   Specialized for Haryana Roadways & State Transit
   ═══════════════════════════════════════════════════ */

const BusInfo = (() => {

  // Add a new bus route via POST /api/routes
  async function addBus(formData) {
    const res = await fetch('/api/routes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to add bus');
    }

    return await res.json();
  }

  // Update existing bus info via PUT /api/routes/:id
  async function updateBus(routeId, formData) {
    const res = await fetch(`/api/routes/${routeId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to update bus details');
    }

    return await res.json();
  }

  // Parse add form
  function parseAddForm(formEl) {
    const busNumber = formEl.querySelector('#input-bus-number').value.trim();
    const from = formEl.querySelector('#input-route-from').value.trim();
    const to = formEl.querySelector('#input-route-to').value.trim();
    const busType = formEl.querySelector('#input-bus-type').value;
    const operator = formEl.querySelector('#input-operator') ? formEl.querySelector('#input-operator').value.trim() : 'Haryana Roadways';
    const driverName = formEl.querySelector('#input-driver-name').value.trim();
    const driverPhone = formEl.querySelector('#input-driver-phone').value.trim();
    const stopsInput = formEl.querySelector('#input-stops').value.trim();

    let stops = [];
    if (stopsInput) {
      stops = stopsInput.split(',').map(s => s.trim()).filter(Boolean);
    }

    return {
      busNumber,
      from,
      to,
      busType,
      operator: operator || 'Haryana Roadways',
      driverName,
      driverPhone,
      stops: stops.length > 0 ? stops : [from, to]
    };
  }

  // Parse edit form
  function parseEditForm(formEl) {
    const routeId = formEl.querySelector('#edit-route-id').value;
    const busNumber = formEl.querySelector('#edit-bus-number').value.trim();
    const from = formEl.querySelector('#edit-route-from').value.trim();
    const to = formEl.querySelector('#edit-route-to').value.trim();
    const busType = formEl.querySelector('#edit-bus-type').value;
    const operator = formEl.querySelector('#edit-operator') ? formEl.querySelector('#edit-operator').value.trim() : 'Haryana Roadways';
    const driverName = formEl.querySelector('#edit-driver-name').value.trim();
    const driverPhone = formEl.querySelector('#edit-driver-phone').value.trim();
    const stopsInput = formEl.querySelector('#edit-stops').value.trim();

    let stops = [];
    if (stopsInput) {
      stops = stopsInput.split(',').map(s => s.trim()).filter(Boolean);
    }

    return {
      routeId,
      data: {
        busNumber,
        from,
        to,
        busType,
        operator: operator || 'Haryana Roadways',
        driverName,
        driverPhone,
        stops: stops.length > 0 ? stops : [from, to]
      }
    };
  }

  // Populate edit form with existing route data
  function populateEditForm(formEl, route) {
    formEl.querySelector('#edit-route-id').value = route.id;
    formEl.querySelector('#edit-bus-number').value = route.busNumber || '';
    formEl.querySelector('#edit-route-from').value = route.from || '';
    formEl.querySelector('#edit-route-to').value = route.to || '';
    formEl.querySelector('#edit-bus-type').value = route.busType || 'Haryana Roadways Superfast / Express';
    if (formEl.querySelector('#edit-operator')) {
      formEl.querySelector('#edit-operator').value = route.operator || 'Haryana Roadways';
    }
    formEl.querySelector('#edit-driver-name').value = route.driverName || '';
    formEl.querySelector('#edit-driver-phone').value = route.driverPhone || '';

    // Format stops as comma-separated string
    if (Array.isArray(route.stops) && route.stops.length > 0) {
      const stopNames = route.stops.map(s => typeof s === 'object' ? s.name : s);
      formEl.querySelector('#edit-stops').value = stopNames.join(', ');
    } else {
      formEl.querySelector('#edit-stops').value = `${route.from}, ${route.to}`;
    }
  }

  // Render bus details in bottom sheet
  function renderBusInfo(route, panelEl) {
    panelEl.querySelector('#bus-info-name').textContent = `${route.busNumber}`;
    panelEl.querySelector('#bus-info-route').textContent = `${route.from} ➔ ${route.to}`;
    panelEl.querySelector('#bus-info-type').textContent = route.busType || 'Haryana Roadways';

    // Live status badge
    const statusEl = panelEl.querySelector('#bus-info-status');
    const activeCountEl = panelEl.querySelector('#bus-info-active-count');
    const activeCount = route.activeBuses || 0;

    if (activeCount > 0) {
      statusEl.textContent = '● Live on Highway';
      statusEl.className = 'badge badge-green';
      activeCountEl.textContent = `${activeCount} bus sharing live GPS`;
    } else {
      statusEl.textContent = '○ Route Registered';
      statusEl.className = 'badge badge-orange';
      activeCountEl.textContent = 'Awaiting live passenger GPS';
    }

    // Driver & meta information
    const metaEl = panelEl.querySelector('#bus-info-meta');
    let metaHtml = '';
    const operator = route.operator || 'Haryana Roadways';
    metaHtml += `<p>🏛️ <strong>Depot / Operator:</strong> ${operator}</p>`;

    if (route.driverName) {
      metaHtml += `<p>🧑‍✈️ <strong>Crew / Driver:</strong> ${route.driverName}</p>`;
    }
    if (route.driverPhone) {
      metaHtml += `<p>📞 <strong>Contact:</strong> <a class="driver-call-link" href="tel:${route.driverPhone}">${route.driverPhone}</a></p>`;
    }
    if (!route.driverName && !route.driverPhone) {
      metaHtml += `<p class="text-muted">ℹ️ Crew details not updated yet. Tap ✏️ to update.</p>`;
    }
    metaEl.innerHTML = metaHtml;

    // Stops / Stations list
    const stopsEl = panelEl.querySelector('#bus-stops-list');
    let stopsHtml = '<h4>Haryana & NCR Station Itinerary</h4>';
    const stops = Array.isArray(route.stops) && route.stops.length > 0
      ? route.stops
      : [{ name: route.from }, { name: route.to }];

    stops.forEach((stop, i) => {
      const stopName = typeof stop === 'object' ? stop.name : stop;
      let dotClass = 'stop-dot';
      if (i === 0) dotClass += ' first';
      else if (i === stops.length - 1) dotClass += ' last';

      stopsHtml += `
        <div class="stop-item">
          <span class="${dotClass}"></span>
          <span>${stopName}</span>
        </div>
      `;
    });
    stopsEl.innerHTML = stopsHtml;
  }

  return {
    addBus,
    updateBus,
    parseAddForm,
    parseEditForm,
    populateEditForm,
    renderBusInfo
  };
})();
