/* ═══════════════════════════════════════════════════
   location.js — Real-Time GPS & Cell Tower Tracking
   ═══════════════════════════════════════════════════ */

const LocationTracker = (() => {
  let watchId = null;
  let isSharing = false;
  let isSimulating = false;
  let currentBusId = null;
  let currentRouteId = null;
  let lastPosition = null;
  let shareInterval = null;
  let simInterval = null;

  // Check if geolocation is supported
  function isSupported() {
    return 'geolocation' in navigator;
  }

  // Get current single position
  function getCurrentPosition() {
    return new Promise((resolve, reject) => {
      if (!isSupported()) {
        reject(new Error('Geolocation not supported on this browser'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          lastPosition = {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracy: Math.round(pos.coords.accuracy || 10),
            speed: pos.coords.speed != null ? Math.round(pos.coords.speed * 3.6) : null, // km/h
            timestamp: pos.timestamp
          };
          resolve(lastPosition);
        },
        (err) => {
          reject(err);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 3000
        }
      );
    });
  }

  // Start continuous real live tracking (passenger on bus)
  function startTracking(busId, routeId, socket, onUpdate) {
    if (!isSupported()) {
      showToast('❌ GPS not supported on this device');
      return false;
    }

    currentBusId = busId;
    currentRouteId = routeId;
    isSharing = true;

    // Start watching position
    watchId = navigator.geolocation.watchPosition(
      (pos) => {
        lastPosition = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: Math.round(pos.coords.accuracy || 10),
          speed: pos.coords.speed != null ? Math.round(pos.coords.speed * 3.6) : null,
          timestamp: pos.timestamp
        };

        if (onUpdate) onUpdate(lastPosition);
      },
      (err) => {
        console.warn('GPS Warning:', err.message);
        if (err.code === 1) {
          showToast('❌ Location permission denied');
          stopTracking(socket);
        } else if (err.code === 2) {
          showToast('⚠️ Position unavailable, trying network towers...');
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 2000
      }
    );

    // Transmit location to server every 4 seconds
    shareInterval = setInterval(() => {
      if (lastPosition && socket && isSharing) {
        socket.emit('share-location', {
          busId: currentBusId,
          routeId: currentRouteId,
          lat: lastPosition.lat,
          lng: lastPosition.lng,
          speed: lastPosition.speed,
          accuracy: lastPosition.accuracy
        });
      }
    }, 4000);

    // Emit initial position right away if ready
    if (lastPosition && socket) {
      socket.emit('share-location', {
        busId: currentBusId,
        routeId: currentRouteId,
        lat: lastPosition.lat,
        lng: lastPosition.lng,
        speed: lastPosition.speed,
        accuracy: lastPosition.accuracy
      });
    }

    return true;
  }

  // Stop tracking
  function stopTracking(socket) {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
      watchId = null;
    }

    if (shareInterval) {
      clearInterval(shareInterval);
      shareInterval = null;
    }

    if (simInterval) {
      clearInterval(simInterval);
      simInterval = null;
      isSimulating = false;
    }

    if (socket && currentBusId) {
      socket.emit('stop-sharing', currentBusId);
    }

    isSharing = false;
    currentBusId = null;
    currentRouteId = null;
  }

  // Start simulation mode (moves along route coordinates smoothly for testing)
  function startSimulation(route, socket, onUpdate) {
    stopTracking(socket);

    currentBusId = `demo-bus-${route.busNumber}`;
    currentRouteId = route.id;
    isSharing = true;
    isSimulating = true;

    // Generate waypoints based on stops or fallback
    let waypoints = [];
    if (Array.isArray(route.stops) && route.stops.length > 0 && route.stops[0].lat) {
      waypoints = route.stops.map(s => ({ lat: s.lat, lng: s.lng }));
    } else {
      // Default sample coordinate path in city
      waypoints = [
        { lat: 28.6139, lng: 77.2090 },
        { lat: 28.5921, lng: 77.1985 },
        { lat: 28.5672, lng: 77.1643 },
        { lat: 28.5410, lng: 77.1290 },
        { lat: 28.5562, lng: 77.1000 }
      ];
    }

    let currentIndex = 0;
    let step = 0;
    const totalSteps = 10;

    function getInterpolatedPoint() {
      const p1 = waypoints[currentIndex];
      const p2 = waypoints[(currentIndex + 1) % waypoints.length];
      const fraction = step / totalSteps;

      return {
        lat: p1.lat + (p2.lat - p1.lat) * fraction,
        lng: p1.lng + (p2.lng - p1.lng) * fraction,
        accuracy: 5,
        speed: 38,
        timestamp: Date.now()
      };
    }

    // Tick every 2.5 seconds
    simInterval = setInterval(() => {
      if (!isSharing) return;

      lastPosition = getInterpolatedPoint();
      step++;
      if (step >= totalSteps) {
        step = 0;
        currentIndex = (currentIndex + 1) % waypoints.length;
      }

      if (onUpdate) onUpdate(lastPosition);

      if (socket) {
        socket.emit('share-location', {
          busId: currentBusId,
          routeId: currentRouteId,
          lat: lastPosition.lat,
          lng: lastPosition.lng,
          speed: lastPosition.speed,
          accuracy: lastPosition.accuracy
        });
      }
    }, 2500);

    // First position immediately
    lastPosition = getInterpolatedPoint();
    if (onUpdate) onUpdate(lastPosition);
    if (socket) {
      socket.emit('share-location', {
        busId: currentBusId,
        routeId: currentRouteId,
        lat: lastPosition.lat,
        lng: lastPosition.lng,
        speed: lastPosition.speed,
        accuracy: lastPosition.accuracy
      });
    }

    return true;
  }

  // Get current sharing state
  function getSharingState() {
    return {
      isSharing,
      isSimulating,
      busId: currentBusId,
      routeId: currentRouteId,
      lastPosition
    };
  }

  return {
    isSupported,
    getCurrentPosition,
    startTracking,
    stopTracking,
    startSimulation,
    getSharingState
  };
})();
